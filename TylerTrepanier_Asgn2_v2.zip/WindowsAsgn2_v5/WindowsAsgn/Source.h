/*=====================================================================================
SOURCE FILE:	Source.h

PROGRAM:		Networking with Windows

FUNCTIONS		void FreeSocketInformation(SOCKET s);
				HWND CreateListView(HWND parent);
				void CreateSocketInformation(SOCKET s);
				LPSOCKET_INFORMATION GetSocketInformation(SOCKET s);
				void GetTextFromHost();
				void GetTextFromPort();
				void updateStatistic(HWND hList, float savg, float ravg, 
										int sent, int recv, double data, int time);
				int WINAPI WinMain(HINSTANCE hInst,
					HINSTANCE hprevInstance,
					LPSTR lspszCmdParam,
					int nCmdShow);
				LRESULT CALLBACK WndProc(HWND hWnd,
					UINT Msg,
					WPARAM wParam,
					LPARAM lParam);

DATE:			January 16th, 2016

REVISIONS:		January 17th, 2016 (Tyler Trepanier-Bracken)
					Organized header file into a cleaner format.
				Febuary 12th, 2016 (Tyler Trepanier-Bracken)
					Moving all the function declarations from Source.cpp to here.

DESIGNER:		Tyler Trepanier-Bracken

PROGRAMMER		Tyler Trepanier-Bracken

NOTES:
Header file declaring all the prototypes required by the Source.cpp file. This is the
main file that will contain the program execution and run from there.
=====================================================================================*/

/*---------------------------------------------------------------------------------
MACROS:			Utility Macros

DATE:			January 17th, 2016

REVISIONS:		January 18th, 2016 (Tyler Trepanier-Bracken)
Removed unused utlity macros.

DESIGNER:		Tyler Trepanier-Bracken

PROGRAMMER:		Tyler Trepanier-Bracken

PURPOSE:
Utility Macros used to assist the Analyze Input function in determining which
function to call.
---------------------------------------------------------------------------------*/
#define EOT 0x04
#define ACK 0x06
#define MAXBUF	65535

/*---------------------------------------------------------------------------------
--	FUNCTION:		Free Socket Information
--
--	DATE:			Febuary 7, 2016
--
--	DESIGNER:		Unknown
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--
--	INTERFACE:		void FreeSocketInformation(SOCKET s)
--
--	RETURNS:		void
--
--	NOTES:
--	Frees the socket information associated to the socket whenever an error
--	occurs, releasing all used data.
---------------------------------------------------------------------------------*/
void FreeSocketInformation(SOCKET s);

/*---------------------------------------------------------------------------------
--	FUNCTION:		Create List View
--
--	DATE:			Febuary 7, 2016
--
--	DESIGNER:		Tyler Trepanier-Bracken
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--
--	INTERFACE:		HWND CreateListView(HWND parent)
--
--	RETURNS:		void
--
--	NOTES:
--	Creates a list view that will display all the data collected during
--	transmission.
---------------------------------------------------------------------------------*/
HWND CreateListView(HWND parent);

/*---------------------------------------------------------------------------------
--	FUNCTION:		Create Socket Information
--
--	DATE:			February 7th, 2016
--
--	DESIGNER:		Unknown
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--
--	INTERFACE:		void CreateSocketInformation(SOCKET s)
--
--	RETURNS:		void
--
--	NOTES:
--	Creates information that will be associated to a created socket. Please
--	refer to the Async.h for detailed information on the LPSOCKET_INFORMATION 
--  structure. 
---------------------------------------------------------------------------------*/
void CreateSocketInformation(SOCKET s);

/*---------------------------------------------------------------------------------
--	FUNCTION:		Create Socket Information
--
--	DATE:			February 7th, 2016
--
--	DESIGNER:		Unknown
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--
--	INTERFACE:		LPSOCKET_INFORMATION GetSocketInformation(SOCKET s)
--
--	RETURNS:		Information associated with a socket. 
--
--	NOTES:
--	Using the socket parameter, it grabs all the associated information with it. 
--	Please refer to the Async.h for detailed information on the 
--	LPSOCKET_INFORMATION structure.
---------------------------------------------------------------------------------*/
LPSOCKET_INFORMATION GetSocketInformation(SOCKET s);

/*---------------------------------------------------------------------------------
--	FUNCTION:		Get Text From Host
--
--	DATE:			January 16, 2016
--
--	REVISED:		January 17, 2016 (Tyler Trepanier-Bracken)
--						Removed unnecessary paramters.
--					Febuary 7th, 2016 (Tyler Trepanier-Bracken)
--						Repurposed Get Text From Input into this function.
--
--	DESIGNER:		Tyler Trepanier-Bracken
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--
--	INTERFACE:		void GetTextFromHost();
--
--	RETURNS:		void
--
--	NOTES:
--	Sends a message to the pre-constructed "host" textfield and
--  sets the host's ip to the text entered in the textbox.
---------------------------------------------------------------------------------*/
void GetTextFromHost();

/*---------------------------------------------------------------------------------
--	FUNCTION:		Get Text From Port
--
--	DATE:			January 16, 2016
--
--	REVISED:		January 17, 2016 (Tyler Trepanier-Bracken)
--						Removed unnecessary paramters.
--					Febuary 7th, 2016 (Tyler Trepanier-Bracken)
--						Repurposed Get Text From Input into this function.
--
--	DESIGNER:		Tyler Trepanier-Bracken
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--
--	INTERFACE:		void GetTextFromPort();
--
--	RETURNS:		void
--
--	NOTES:
--	Sends a message to the pre-constructed "input" textfield and sets the port 
--	to the text entered in the textbox.
---------------------------------------------------------------------------------*/
void GetTextFromPort();

/*---------------------------------------------------------------------------------
--	FUNCTION:		Set Output Text
--
--	DATE:			January 17, 2016
--
--	DESIGNER:		Tyler Trepanier-Bracken
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--
--	INTERFACE:		void updateStatistic(HWND hList, float savg, float ravg, 
--						int sent, int recv, double data, int time);
--
--	PARAMETERS:		HWND hList, 
--						Handle to the list which will display the data.
--					float savg, 
--						Average send time for a single packet.
--					float ravg, 
--						Average receive time for a single packet.
--					int sent, 
--						Number of packets sent.
--					int recv, 
--						Number of packets received.
--					double data, 
--						Total data, in MB sent and received.
--					int time
--						Total time spent doing sending and receiving.
--
--	RETURNS:		void
--
--	NOTES:
--	Sets the output of the list to the parameters specified.
---------------------------------------------------------------------------------*/
void updateStatistic(HWND hList, float savg, float ravg, 
						int sent, int recv, double data, int time);

/*---------------------------------------------------------------------------------
--	FUNCTION:		WinMain
--
--	DATE:			October 17, 2015
--
--	REVISIONS:		January 17, 2016 (Tyler Trepanier-Bracken)
--						Created the windows using C++ code instead of resources
--						and transferred all child window creating to the WM_CREATE
--						portion inside of WndProc (Windows Procedure).
--					January 16, 2016 (Tyler Trepanier-Bracken)
--						Repurposed this function from the SkyeTek application that
--						was made previously. In addition, used a combobox dialog
--						message box to contain all the child windows needed.
--
--
--	DESIGNER:		Microsoft Corporation (Original Designer)
--
--	PROGRAMMER:		Tyler Trepanier-Bracken (Re-purposed for this application.)
--
--	INTERFACE:		int APIENTRY WinMain(HINSTANCE hInst, HINSTANCE hprevInstance,
--						PWSTR lspszCmdParam, int nCmdShow)
--
--	PARAMETERS:		HINSTANCE hInst
--						Handle to the current instance of the application.
--					HINSTANCE hprevInstance
--						Handle to the previous instance of the application.
--						For a Win32-based application, this parameter is always NULL.
--					PWSTR lspszCmdParam
--						Pointer to a null-terminated string that specifies the command
--						line for the application, excluding the program name.
--					int nCmdShoW
--						Specifies how the window is to be shown.
--
--	RETURNS:		The exit value contained in that message's wParam
--					parameter indicates success, and that the function
--					terminates when it receives a WM_QUIT message. Zero
--					indicates that the function terminates before entering
--					the message loop.
--
--	NOTES:
--	This function is called by the system as the initial entry point for
--	Windows Embedded CE-based applications. Used to create the window
--	where the application will take place.
---------------------------------------------------------------------------------*/
int WINAPI WinMain(HINSTANCE hInst,
	HINSTANCE hprevInstance,
	LPSTR lspszCmdParam,
	int nCmdShow);

/*---------------------------------------------------------------------------------
--	FUNCTION:		Window Procedure
--
--	DATE:			October 17, 2015
--
--	REVISIONS:		January 17, 2016 (Tyler Trepanier-Bracken)
--						-Removed all combo box creation/destruction code and
--						 instead added the pre-existed child elements to a standard
--						 static sized window.
--						-Added an additional text field for output to be displayed
--						 upon
--						-Implemented AnalyzeInput function.
--						-Implemented "Clear" button functionality.
--					January 16, 2016 (Tyler Trepanier-Bracken)
--						Modified existing code to create the input text field,
--						list and two buttons (convert / clear) inside of the
--						Combo Box Dialog window.
--
--
--	DESIGNER:		Aman Abdulla (Original Designer)
--
--	PROGRAMMER:		Tyler Trepanier-Bracken
--						(Re-purposed from SkyeTek RFID Scanner)
--						(Originally re-purposed from Lab: Menu Example #5)
--
--	INTERFACE:		LRESULT CALLBACK WndProc(
--						HWND hwnd,
--						UINT Message,
--						WPARAM wParam,
--						LPARAM lParam)
--
--	PARAMETERS:		HWND hwnd
--						Window handle to designated for this specific application
--					UINT Message
--						Message received from Windows.
--					WPARAM wParam
--						Input received from keyboard.
--					LPARAM lParam
--						Input received from mouse.
--
--	RETURNS:		LRESULT CALLBACK.
--
--	NOTES:
--	Handles the continous stream of messages and input sent from Windows and
--	the user.
--
--	WM_COMMAND
--		IDC_CONVERT:	Perform the AnalyzeInput function on the input text
field.
--		IDC_CLEAR:		Clear all text in the output field.
--
--	WM_CREATE:			Creates several child elements to be placed inside of
the parent window
--							-input:		Input text field
--							-output:	Output text field
--							-combobox:	List of available conversions
--							-covertBtn: Convert button that converts text input
and uses it.
--							-clearBtn:	Clears the output text fields.
--
--	WM_DESTROY
--		Closes the application.
--
---------------------------------------------------------------------------------*/
LRESULT CALLBACK WndProc(HWND hWnd,
	UINT Msg,
	WPARAM wParam,
	LPARAM lParam);

